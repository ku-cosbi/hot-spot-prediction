from Bio.PDB import *
import math,operator
import sys, os
import collections
import re
import numpy as np
from dictionaries import *
import pdb as debug
import re

INTERFACE_RESIDUES = dict()
chain1InterfaceRes = []
chain2InterfaceRes = []
chain1 = []
chain2 = []
resList= []
ASAinComplex = dict()
ASAinMonomer = dict()
CenterOfMass = dict()
NEIGHBOR_RESIDUES = dict()
PAIR_POTENTIALS = dict()
hotspotresidues1 = []
hotspotresidues2 = []
#################### Find hotspots and non-hotspots ###############
def HotPoint():
	allInterfaceRes = chain1InterfaceRes + chain2InterfaceRes
	for residue in allInterfaceRes:
		try:
			compASA=ASAinComplex[residue]
			monoASA=ASAinMonomer[residue]
			maxASA=MAX_ASA[residue.get_resname()]
			relCompASA=compASA/maxASA*100
			relMonoASA=monoASA/maxASA*100
			relDeltaASA=(monoASA-compASA)/maxASA*100
			if (relCompASA <=20 and PAIR_POTENTIALS[residue]>=18.0):
				if(residue in chain1InterfaceRes):
					hotspotresidues1.append([residue.get_id()[1], residue, relCompASA, relMonoASA, "H"])
				else:
					hotspotresidues2.append([residue.get_id()[1], residue, relCompASA, relMonoASA, "H"])
			else:
				if(residue in chain1InterfaceRes):
					hotspotresidues1.append([residue.get_id()[1], residue, relCompASA, relMonoASA, "NH"])
				else:
					hotspotresidues2.append([residue.get_id()[1], residue, relCompASA, relMonoASA, "NH"])
		except:
			pass
	return

#################### Calculate Pair Potential ###############
def distanceCalculation(vec1, vec2):
	x1 = vec1[0]
	y1 = vec1[1]
	z1 = vec1[2]

	x2 = vec2[0]
	y2 = vec2[1]
	z2 = vec2[2]

	distance = math.sqrt(((x2-x1)**2)+((y2-y1)**2)+((z2-z1)**2))
	return distance

def centerOfMass():
	for res1 in resList:
		if(len(res1.get_resname()) >3):
			resname = res1.get_resname()[1:4]
		else:
			resname = res1.get_resname()
		try:
			numAtoms1 = len(DICT_ATOM[resname])	
			x_total1= 0
			y_total1=0
			z_total1=0
			
			for atom1 in res1:
				if(atom1.get_id() in DICT_ATOM[resname]):
					x_total1+=atom1.get_coord()[0]
					y_total1+=atom1.get_coord()[1]
					z_total1+=atom1.get_coord()[2]
			com1 = [x_total1/numAtoms1,y_total1/numAtoms1,z_total1/numAtoms1]
			CenterOfMass[res1] = com1
		except:
			pass
	return
'''
def findNeighbors():
	nonInterface1 = set(Selection.unfold_entities(chain1, 'R')) - set(chain1InterfaceRes)
	for res1 in chain1InterfaceRes:
		NEIGHBOR_RESIDUES_CH1[res1] = []
		for res2 in nonInterface1:
			CA1 = res1['CA']
			CA2 = res2['CA']
			diff = CA1 - CA2
			if (diff <=6):
				NEIGHBOR_RESIDUES_CH1[res1].append(res2)
	nonInterface2 = set(Selection.unfold_entities(chain2, 'R')) - set(chain2InterfaceRes)
	for res1 in chain2InterfaceRes:
		NEIGHBOR_RESIDUES_CH2[res1] = []
		for res2 in nonInterface2:
			CA1 = res1['CA']
			CA2 = res2['CA']
			diff = CA1 - CA2
			if (diff <=6):
				NEIGHBOR_RESIDUES_CH2[res1].append(res2)
'''

def ExtractNeighbors():	
	centerOfMass()
	allInterfaceRes = chain1InterfaceRes + chain2InterfaceRes
	for res1 in allInterfaceRes:
		NEIGHBOR_RESIDUES[res1]= []
		for res2 in CenterOfMass.keys():
			if (res1 != res2):
				if (res1.get_parent().id == res2.get_parent().id): #they are in the same chain
					if(abs(res1.get_id()[1]-res2.get_id()[1]) >= 4):
						com1 = CenterOfMass[res1]
						com2 = CenterOfMass[res2]
						dist = distanceCalculation(com1,com2)
						if (dist <= 7.0):
							NEIGHBOR_RESIDUES[res1].append(res2)
				else:
					com1 = CenterOfMass[res1]
					com2 = CenterOfMass[res2]
					dist = distanceCalculation(com1,com2)
					if (dist <= 7.0):
						NEIGHBOR_RESIDUES[res1].append(res2)
	return
			
def contactPotentials(residue):
	neighbors = NEIGHBOR_RESIDUES[residue]
	sumOfpairPotentials = 0.0
	for n in neighbors:
		indexI = PP_indices[residue.get_resname()]
		indexJ = PP_indices[n.get_resname()]
		if(CONTACT_POTENTIALS[indexI][indexJ] != 0):
			sumOfpairPotentials+=CONTACT_POTENTIALS[indexI][indexJ]
		else:
			sumOfpairPotentials+=CONTACT_POTENTIALS[indexJ][indexI]
	return sumOfpairPotentials

def PairPotentials():
	ExtractNeighbors()
	allInterfaceRes = chain1InterfaceRes + chain2InterfaceRes
	for res in allInterfaceRes:
		PAIR_POTENTIALS[res] = abs(contactPotentials(res))
				
#################### Calculate RelASA #######################
def parseNaccessFile(pdbPath, interfaceID):
	nfile = open(pdbPath+ "/" +interfaceID.lower()+".naccess","r")
	line = nfile.readline()
	while line:
		if line.startswith("RES"):
			resPosition = line[9:14].replace(" ","")
			chain = line[8]
			if (chain == chain1.id) :
				residue = chain1[int(re.sub("\D", "", resPosition))]
				if (residue in chain1InterfaceRes):
					temp = line[14:].strip().split()
					ASA = float(temp[0])
					ASAinComplex[residue] = ASA
			else:
				residue = chain2[int(re.sub("\D", "", resPosition))]
				if (residue in chain2InterfaceRes):
					temp = line[14:].strip().split()
					ASA = float(temp[0])
					ASAinComplex[residue] = ASA
		line = nfile.readline()
	nfile.close()


	monomer1 = interfaceID[0:5].lower()
	monomer2 = interfaceID[0:4].lower()+interfaceID[5].lower()
	nmfile = open(pdbPath + "/" + monomer1+".naccess" ,"r")
	line = nmfile.readline()
	while line:
		if line.startswith("RES"):
			resPosition = line[9:14].replace(" ","")
			residue=chain1[int(re.sub("\D", "", resPosition))]
			if (residue in chain1InterfaceRes):
				temp=line[14:].strip().split()
				ASA=float(temp[0])
				ASAinMonomer[residue]=ASA
		line = nmfile.readline()
	nmfile.close()

	nmfile = open(pdbPath+ "/" +monomer2+".naccess","r")
	line = nmfile.readline()
	while line:
		if line.startswith("RES"):
			resPosition = line[9:14].replace(" ","")
			residue = chain2[int(re.sub("\D", "", resPosition))]
			if (residue in chain2InterfaceRes):
				temp = line[14:].strip().split()
				ASA = float(temp[0])
				ASAinMonomer[residue] = ASA
		line = nmfile.readline()
	nmfile.close()
	return

def calcSASA(pdbPath, pdb_file):
	pdb_file = pdb_file.lower()
	pdb_ID = pdb_file
	pdb_file = "%s.pdb" %(pdb_file)
	cmd = "%s/naccess %s > out.txt 2>error.txt" %("naccess",pdb_file)
	os.system("cp %s/%s.pdb naccess/%s.pdb " %(pdbPath, pdb_ID, pdb_ID))
	os.chmod("naccess/%s.pdb" %(pdb_ID), 777)
	os.chdir("naccess")
	os.system(cmd)
	os.chdir("..")
	os.system("cp naccess/%s.rsa %s/%s.naccess" %(pdb_ID, pdbPath, pdb_ID))
	os.system("chmod -R 777 %s" %(pdbPath))	
	os.system("chmod -R 777 naccess")
	os.system("rm naccess/*.log naccess/*.asa naccess/*.pdb naccess/*.rsa")
	return

def parseChainAtoms(pdbPath, interfaceID):
	os.system("chmod -R 777 %s" %(pdbPath))
	pdbID = interfaceID[0:4]
	pdbFilePath = "%s/%s.pdb" % (pdbPath,pdbID)
	ch1 = interfaceID[4]
	ch2 = interfaceID[5]
	class Chain1Select(Select):
		def accept_chain(self, chain):
			if chain.id==ch1:
				return 1
			else:
				return 0
	class Chain2Select(Select):
		def accept_chain(self, chain):
			if chain.id==ch2:
				return 1
			else:
				return 0
	class Chain12Select(Select):
		def accept_chain(self, chain):
			if (chain.id==ch2) or (chain.id==ch1):
				return 1
			else:
				return 0
	io = PDBIO()
	io.set_structure(structure)
	io.save("%s/%s%s.pdb" %(pdbPath,pdbID.lower(), ch1.lower()), Chain1Select())
	io.save("%s/%s%s.pdb" %(pdbPath,pdbID.lower(), ch2.lower()), Chain2Select())
	io.save("%s/%s%s.pdb" %(pdbPath,pdbID.lower(), ch1.lower()+ch2.lower()), Chain12Select())
	return

def RunNaccess(pdbPath, interfaceID):
	parseChainAtoms(pdbPath, interfaceID)
	pdb_id = interfaceID[0:4]
	for structure in [pdb_id+interfaceID[4], pdb_id+interfaceID[5], interfaceID]:
		calcSASA(pdbPath, structure)
	parseNaccessFile(pdbPath, interfaceID)

#################### Find Interface Residues #######################
def findInteractingPairs(residue1, residue2, threshold):
	for atom1 in residue1:
		for atom2 in residue2:
			try:
				r1 = VDW_RADII_EXTENDED[residue1.get_resname()][atom1.get_id()]
				r2 = VDW_RADII_EXTENDED[residue2.get_resname()][atom2.get_id()]
				distance = abs(atom1 - atom2)
				if(distance < (r1+r2+threshold)):
					INTERFACE_RESIDUES[residue1].append(residue2)
					if(residue1 not in chain1InterfaceRes):
						chain1InterfaceRes.append(residue1)
					if(residue2 not in chain2InterfaceRes):
						chain2InterfaceRes.append(residue2)
					return
			except:
				pass
	return



def ExtractInterfaceResidues(threshold):
	for residue1 in chain1:
		INTERFACE_RESIDUES[residue1] = []
		for  residue2 in chain2:
			findInteractingPairs(residue1, residue2, threshold)
	return

#################### Write Results ##############
def WriteResults(pdbPath, interfaceID):
	file = open("%s/%s.result" % (pdbPath, interfaceID), "w")
	newfile = open("%s/%s.output" % (pdbPath, interfaceID), "w")
	jmolfile = open("%s/%s.spt" % (pdbPath, interfaceID), "w")

	file.writelines("Residue Number_Residue Name_Chain_RelCompASA_RelMonomerASA_Potential_Prediction\n")
	newfile.writelines("Residue Number\tResidue Name\tChain\tRelCompASA\tRelMonomerASA\tPotential\tPrediction\n")
	newfile.writelines("------------------------------------------------------------------------------------------------------\n")

	pdbID = interfaceID[0:4]
	chain1id = interfaceID[4]
	chain2id = interfaceID[5]

	jmolfile.writelines("zap;\n")
	jmolfile.writelines("load %s.pdb;\n" % (pdbPath + "/" + pdbID))
	jmolfile.writelines("background white;\n")    
	jmolfile.writelines("wireframe off;\n")    
	jmolfile.writelines("restrict none;\n")    
	jmolfile.writelines("select *:%s;\n" %(chain1id))       
	jmolfile.writelines("select selected or *:%s;\n" %(chain2id))    
	jmolfile.writelines("trace on;\n")     
	jmolfile.writelines("select *:%s;\n" %(chain1id))    
	jmolfile.writelines("color cyan;\n")  
	jmolfile.writelines("select *:%s;\n" %(chain2id)) 
	jmolfile.writelines("color orange;\n")    
	jmolfile.writelines("select none;\n")   

	temp1 = sorted(hotspotresidues1 , key=operator.itemgetter(0))
	temp2 = sorted(hotspotresidues2 , key=operator.itemgetter(0))

	for res in temp1:
		if res[4]=="H":
			jmolfile.writelines("select selected or %s:%s;\n" %(int(res[0]),res[1].get_parent().id ))  

	jmolfile.writelines("color red;\n")  
	jmolfile.writelines("select none;\n")   

	for res in temp2:
		if res[4]=="H":
			jmolfile.writelines("select selected or %s:%s;\n" %(int(res[0]),res[1].get_parent().id ))  

	jmolfile.writelines("color purple;\n")  
	jmolfile.writelines("select none;\n")   

	for res in temp1:
		file.writelines("%d_%s_%s_%6.2f_%6.2f_%6.2f_%s\n" %(res[0] , three2one(res[1].get_resname()) , res[1].get_parent().id , res[2] , res[3] , PAIR_POTENTIALS[res[1]] , res[4]))
		newfile.writelines("%d\t\t%s\t\t%s\t%6.2f\t\t%6.2f\t\t%6.2f\t\t%s\n"  %(res[0] , three2one(res[1].get_resname()) , res[1].get_parent().id , res[2] , res[3] , PAIR_POTENTIALS[res[1]] , res[4]))
		jmolfile.writelines("select selected or %s:%s;\n" %(int(res[0]),res[1].get_parent().id))  


	for res in temp2:
		file.writelines("%d_%s_%s_%6.2f_%6.2f_%6.2f_%s\n"%(res[0] , three2one(res[1].get_resname()) , res[1].get_parent().id , res[2] , res[3] , PAIR_POTENTIALS[res[1]] , res[4]))
		newfile.writelines("%d\t\t%s\t\t%s\t%6.2f\t\t%6.2f\t\t%6.2f\t\t%s\n" %(res[0] , three2one(res[1].get_resname()) , res[1].get_parent().id , res[2] , res[3] , PAIR_POTENTIALS[res[1]] , res[4]))
		jmolfile.writelines("select selected or %s:%s;\n" %(int(res[0]),res[1].get_parent().id))  

	jmolfile.writelines("wireframe off;\n")    
	jmolfile.writelines("spacefill on;\n")  
	jmolfile.writelines("define bothChains selected;\n")    
	jmolfile.writelines("select bothChains and *:%s;\n" %(chain1id))    
	jmolfile.writelines("define chainOne selected;\n")   
	jmolfile.writelines("select bothChains and *:%s;\n" %(chain2id))   
	jmolfile.writelines("define chainTwo selected;\n")       
    
	jmolfile.close()
	file.close()
	newfile.close()
	return 1



#################### Main #######################
if len(sys.argv) == 4:
	interfaceID = sys.argv[1]
	pdbPath = sys.argv[2]
	thresholdvalue = float(sys.argv[3])
	parser = PDBParser()
	structure = parser.get_structure('myPDBStructure', "%s/%s.pdb" %(pdbPath,interfaceID[0:4]))
	io = PDBIO()
	io.set_structure(structure)
	model = structure[0]
	chain1 = model[interfaceID[4]]
	chain2 = model[interfaceID[5]]
	resList = Selection.unfold_entities(structure, 'R')
	ExtractInterfaceResidues(thresholdvalue)
	RunNaccess(pdbPath,interfaceID)
	PairPotentials()
	HotPoint()
	WriteResults(pdbPath,interfaceID)
else:
	print("Usage: python hotpoint.py <interface id> <pdb file path> <threshold>")

	#prints interface residues
	'''
	allinterfaceres = hotspotresidues1 + hotspotresidues2
	for key in allinterfaceres:
		print(key[1].get_resname()+" "+str(key[0])+" "+key[1].get_parent().id+" "+key[4])
	'''

	
